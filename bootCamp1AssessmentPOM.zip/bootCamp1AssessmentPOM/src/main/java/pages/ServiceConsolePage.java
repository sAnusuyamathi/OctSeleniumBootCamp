package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class ServiceConsolePage extends ProjectSpecificMethods {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	
	public ServiceConsolePage verifyServiceConsole() {
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[@title='Service Console']"))));
		if(driver.findElement(By.xpath("//span[@title='Service Console']")).getText().contains("Service Console")) {
			System.out.println("Navigated to Service Console");
		}
		else
		{
			System.out.println("Not navigated to service console");
		}
		return this;
	}
	
	public ServiceConsolePage clickShowNavigations() {
		
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("(//span[text()='Dashboards']/following::span[text()='Show Navigation Menu'])[1]")));
		return this;

	}
	
	public HomeFromDDPage selectHomeFromDropDown() {
	 WebElement homeElement = driver.findElement(By.xpath("//span[text()='Home']"));
	 Actions builder = new Actions(driver);
	 builder.moveToElement(homeElement).click().perform();
	 return new HomeFromDDPage();
	}
	
	}
