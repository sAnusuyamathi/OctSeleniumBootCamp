package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{

	public HomePage verifyPage() throws InterruptedException {
//		System.out.println("Home page is launched");
		Thread.sleep(10000);
		if(driver.getTitle().contains("Home")) {
			System.out.println("Home page is launched");
		}
		return this;
	
	}
	
	public HomePage clickAppLauncher() {
		driver.executeScript("arguments[0].click();", driver.findElement(By.className("slds-icon-waffle")));
		return this;
	}
	public HomePage clickViewAll() {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		return this;
	}
	
	public ServiceConsolePage clickServiceConsole() throws InterruptedException {
		Thread.sleep(10000);
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//p[text()='Service Console']")));
		return new ServiceConsolePage();

	}

}
