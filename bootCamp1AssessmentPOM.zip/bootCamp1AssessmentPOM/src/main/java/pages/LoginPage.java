package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
		
	public LoginPage enterUserName(String userName) {
		driver.findElement(By.id("username")).sendKeys(userName);
		return this;
	}
	public LoginPage enterPassWord(String passWord) {
		driver.findElement(By.id("password")).sendKeys(passWord);
		return this;
	}
	
	public HomePage clickLogin() {
		driver.findElement(By.id("Login")).click();
		return new HomePage();
	}
}
