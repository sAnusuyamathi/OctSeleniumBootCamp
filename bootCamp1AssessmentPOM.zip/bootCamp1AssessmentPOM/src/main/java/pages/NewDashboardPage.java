package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class NewDashboardPage extends ProjectSpecificMethods {

	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	WebElement findEle = driver.findElement(By.xpath("//iFrame[1]"));
	public NewDashboardPage verifyNewDashboardPage() throws InterruptedException {
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		System.out.println(driver.findElements(By.xpath("//iFrame[1]")).size());
//		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(findEle));
		Thread.sleep(10000);
		driver.switchTo().frame(findEle);
		if(driver.findElement(By.xpath("//h2[text()='New Dashboard']")).isDisplayed()) {
			System.out.println("Navigated to New dashboards page");
			
		}
		else
		{
			System.out.println("Not navigated to new dashboards page");
		}
		return this;

	}
	
	public NewDashboardPage enterNameInDashboard() throws InterruptedException {
		
		
//		System.out.println(findEle.size());
		Thread.sleep(10000);
//		driver.switchTo().frame(findEle);
		driver.findElement(By.id("dashboardNameInput")).sendKeys("Anu_Workout");
		return this;
	}
	
	public NewDashboardPage enterDescInDasboard() throws InterruptedException {
		Thread.sleep(10000);
		driver.findElement(By.id("dashboardDescriptionInput")).sendKeys("Testing"); 
		return this;
	}
	
	public DashboardCreatedPage clickCreateInNewDashboard() throws InterruptedException {
		Thread.sleep(10000);
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//button[text()='Create']")));
		driver.switchTo().defaultContent();
		return new DashboardCreatedPage();
	}
	
	
}
