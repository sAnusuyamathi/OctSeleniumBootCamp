package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class DashBoardsFromDDPage extends ProjectSpecificMethods {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	Actions builder= new Actions(driver);
	public DashBoardsFromDDPage verifyDashboardPage() {
		
		wait.until(ExpectedConditions.titleContains("Dashboards"));
		if(driver.getTitle().contains("Dashboards")) {
			System.out.println("Navigated to dashboards page");
		}
		else
		{
			System.out.println("Not navigated to dashboards page");
		}
		return this;
	}
	
	public NewDashboardPage clickNewDashboard() {
		
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//div[@title='New Dashboard']")));
		return new NewDashboardPage();
	}
	
	public DashBoardsFromDDPage clickPrivateDashboards() {
		driver.findElement(By.xpath("//li[@class='slds-nav-vertical__item scope slds-is-active']//a[1]")).click();
		return this;
	}
	
	public DashBoardsFromDDPage searchNewDashboard() {
		driver.findElement(By.xpath("//input[@placeholder='Search private dashboards...']")).sendKeys("Anu_Workout");
		builder.moveToElement(driver.findElement(By.xpath("//input[@placeholder='Search private dashboards...']"))).click().perform();
		
		return this;

	}
	public DashBoardsFromDDPage verifySearchResult() {
		if(driver.findElements(By.xpath("//table//tr/th[1]//a[@title='Anu_Workout']")).size() > 0) {
			driver.findElement(By.xpath("//table/tbody/tr[1]/td[6]")).click();
		}
		else {
			System.out.println("No results found");
		}
		return this;
	}
	public DashBoardsFromDDPage clickMoreActionsFromSearchResult() {
		driver.findElement(By.xpath("//span[text()='Show actions']/ancestor::td[1]")).click();
		return this;

	}
	
	public DeleteDashboardPage selectDeleteFromShowActions() throws InterruptedException {
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click();",driver.findElement(By.xpath("//span[text()='Delete']")));
		return new DeleteDashboardPage();

	}
	public DashBoardsFromDDPage verifyDeleteToastMsg() throws InterruptedException {
		Thread.sleep(5000);
		if(driver.findElement(By.xpath("//span[@data-aura-class='forceActionsText']")).getText().contains("Dashboard was deleted")) {
			System.out.println("Deleted successfully");
		}
		else {System.out.println("Not Deleted");
			}
		return this;
	}
}
