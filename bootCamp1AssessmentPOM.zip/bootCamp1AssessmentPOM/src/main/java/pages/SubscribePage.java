package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class SubscribePage extends ProjectSpecificMethods{
	Actions builder = new Actions(driver);
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	public SubscribePage verifySubscribePage() throws InterruptedException {
		Thread.sleep(10000);
		System.out.println(driver.findElements(By.xpath("//iFrame")).size());
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h2[text()='Edit Subscription']"))));
		if(driver.findElement(By.xpath("//h2[text()='Edit Subscription']")).getText().contains("Edit Subs")) {
			System.out.println("Subscription page is displayed");
		}
		else {
			System.out.println("Subscription is not displayed");
		}
			
		return this;

	}
	
	public SubscribePage clickDaily() throws InterruptedException {
		Thread.sleep(10000);
		builder.moveToElement(driver.findElement(By.xpath("//span[text()='Daily']"))).click().perform();
		return this;
	}
	
	public SubscribePage selectTimeFromDD() throws InterruptedException {
		Thread.sleep(10000);
		WebElement ddEle = driver.findElement(By.xpath("//select[@class=' select']"));
		Select ddTime = new Select(ddEle);
		ddTime.selectByValue("10");;
		return this;
	}
	
	public DashboardCreatedPage clickSave() {
		builder.moveToElement(driver.findElement(By.xpath("//button[@title='Save']"))).click().perform();
		return new DashboardCreatedPage();
	}
	
	
}
