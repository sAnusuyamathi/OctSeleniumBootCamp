package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.ProjectSpecificMethods;

public class HomeFromDDPage extends ProjectSpecificMethods {

	
	public HomeFromDDPage verifyHomeDropDownIsDisplayed() {
		wait.until(ExpectedConditions.titleContains("Home"));
		if(driver.getTitle().contains("Home")) {
			System.out.println("Home page is displayed");
		}
		else 
			{
				System.out.println("Home page is not displayed");
			}
		return this;
		}
	
	public HomeFromDDPage clickShowNavigationsFromHome() {
		
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("(//span[text()='Home']/following::span[text()='Show Navigation Menu'])[1]")));
		return this;

	}
	
	public DashBoardsFromDDPage selectDashBoardFromDropDown() {
		 WebElement homeElement = driver.findElement(By.xpath("//span[text()='Dashboards']"));
		 Actions builder = new Actions(driver);
		 builder.moveToElement(homeElement).click().perform();
		 return new DashBoardsFromDDPage();
	}
}
