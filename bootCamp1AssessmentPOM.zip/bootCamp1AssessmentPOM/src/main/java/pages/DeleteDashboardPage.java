package pages;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class DeleteDashboardPage extends ProjectSpecificMethods{

	public DeleteDashboardPage verifyDeleteDashboard() throws InterruptedException {
		Thread.sleep(8000);
		if(driver.findElement(By.xpath("//h2[text()='Delete Dashboard']")).isDisplayed()) {
			System.out.println("Delete Dashboard is displayed");
		}
		else {
			System.out.println("Delete Dashboard isnot displayed");
	}
		return this;

	}
	public DashBoardsFromDDPage clickDelete() {
	driver.executeScript("arguments[0].click();",driver.findElement(By.xpath("//button[@title='Delete']")));
	return new DashBoardsFromDDPage();
	}
	
}
