package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class DashboardCreatedPage extends ProjectSpecificMethods{
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
//	WebElement findEle = driver.findElement(By.xpath("//iFrame[1]"));
	public DashboardCreatedPage verifyNewlyCreatedDashboardPage() {
		
		wait.until(ExpectedConditions.titleContains("Anu_Workout"));
		if(driver.getTitle().contains("Anu_Workout")) {
			System.out.println("Navigated to Anu_Workout dashboards page");
			
		}
		else
		{
			System.out.println("Not navigated to Anu_Workout dashboards page");
		}
		return this;

	}
	
	public DashboardCreatedPage verifyVisibilityOfDone() throws InterruptedException {
		driver.switchTo().defaultContent();
		System.out.println(driver.findElements(By.xpath("//iFrame")).size());
		Thread.sleep(10000);
		return this;
	}
	public DashboardCreatedPage clickDoneOnDashboard() throws InterruptedException {
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		WebElement findEle = driver.findElement(By.xpath("//iFrame[1]"));
		driver.switchTo().frame(findEle);
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//button[text()='Done']")));
		return this;
	}
	
	public DashboardCreatedPage verifySuccessfulCreation() throws InterruptedException {
		Thread.sleep(10000);
//		driver.switchTo().defaultContent();
//		Thread.sleep(10000);
//		WebElement findEle = driver.findElement(By.xpath("//iFrame[1]"));
//		driver.switchTo().frame(findEle);
//		Thread.sleep(10000);
//		wait.until(ExpectedConditions.textToBePresentInElementValue(By.xpath("(//a[@title='Anu_Workout']//span[2])[1]"), "Anu_Workout"));
		if(driver.getTitle().contains("Anu_Workout")) {
//		if(driver.findElement(By.xpath("(//a[@title='Anu_Workout']//span[2])[1]")).getText().contains("Anu_Workout")) {
			System.out.println("New dashboard is created");
		}
		else {
			System.out.println("New Dashboard is not created");
		}
		return this;
	}
	
	public SubscribePage clickSubscribeButton() throws InterruptedException {
		driver.switchTo().defaultContent();
		Thread.sleep(10000);
		WebElement findEle = driver.findElement(By.xpath("//iFrame[1]"));
		driver.switchTo().frame(findEle);
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//button[text()='Subscribe']")));
		return new SubscribePage();
	}
	
	public DashBoardsFromDDPage verifySubscriptionMsg() {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[contains(@data-aura-class,'forceActionsText')]")));
		if(driver.findElement(By.xpath("//span[contains(@data-aura-class,'forceActionsText')]")).getText().contains("You started a dashboard subscription.")){
			System.out.println("Subscribed successfully");

	}
		else {
			System.out.println("Not Subscribed");
		}
	
		return new DashBoardsFromDDPage();
	}
	
	public DashBoardsFromDDPage closeCreatedDashboard() {

		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//button[@title='Close Anu_Workout']")));
		return new DashBoardsFromDDPage();
	}
	public DashBoardsFromDDPage verifyDashboardClosed() throws InterruptedException {
		Thread.sleep(5000);
		
		if(driver.findElement(By.xpath("//span[@title='Anu_Workout']")).isDisplayed()==false) {
			System.out.println("Dashboard Anu_Workout is closed");
		}
		
		else {System.out.println("Dashboard Anu_Workout is not closed");
		}
		return new DashBoardsFromDDPage();

	}
	
	private void verifyNoResults() {
		driver.findElement(By.xpath("//label[text()='Search recent dashboards...']/following::input[1]")).sendKeys("Salesforce Anu");
		if(driver.findElement(By.xpath("//span[@class='emptyMessageTitle']")).getText().contains("No results found")){
			System.out.println("No results found");
	}

}
}

