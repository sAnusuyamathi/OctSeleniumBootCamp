package testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class Dashboard extends ProjectSpecificMethods{
	@Parameters({"uName","pWord"})
	@Test
	public void runDashboard(String userName,String passWord) throws InterruptedException {
		new LoginPage()
		.enterUserName(userName)
		.enterPassWord(passWord)
		.clickLogin()
		.verifyPage()
		.clickAppLauncher()
		.clickViewAll()
		.clickServiceConsole()
		.verifyServiceConsole()
		.clickShowNavigations().selectHomeFromDropDown()
		.clickShowNavigationsFromHome().selectDashBoardFromDropDown()
		.clickNewDashboard()
		.verifyNewDashboardPage()
		.enterNameInDashboard()
		.enterDescInDasboard()
		.clickCreateInNewDashboard()
		.verifyNewlyCreatedDashboardPage()
		.verifyVisibilityOfDone()
		.clickDoneOnDashboard()
		.verifySuccessfulCreation()
		.clickSubscribeButton()
		.verifySubscribePage()
		.clickDaily()
		.selectTimeFromDD()
		.clickSave()
		.verifySubscriptionMsg()
		.verifyDashboardPage()
		.clickPrivateDashboards()
		.searchNewDashboard()
		.verifySearchResult()
		.clickMoreActionsFromSearchResult()
		.selectDeleteFromShowActions()
		.verifyDeleteDashboard()
		.clickDelete()
		.verifyDeleteToastMsg();
}
}